# TODO: merge and compute rates

school_rates =   # replace with your result
display(school_rates.head(10))