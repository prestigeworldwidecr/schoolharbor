attendance = pd.read_csv("data/attendance.csv", parse_dates=["date"])

# TODO: compute ADA grouped by school and YYYY-MM

ada_by_school_month = # replace

display(ada_by_school_month.head(10))